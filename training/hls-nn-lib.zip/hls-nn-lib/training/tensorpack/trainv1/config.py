# -*- coding: utf-8 -*-
# File: config.py


__all__ = ['TrainConfig']

from ..train.config import TrainConfig
