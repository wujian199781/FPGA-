#!/usr/bin/env python
# -*- coding: utf-8 -*-
# File: utility.py

# for backwards-compatibility
from ..graph_builder.utils import (  # noqa
    override_to_local_variable, LeastLoadedDeviceSetter)
