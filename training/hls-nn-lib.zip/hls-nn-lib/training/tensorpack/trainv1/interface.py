#!/usr/bin/env python
# -*- coding: utf-8 -*-
# File: interface.py


__all__ = ['launch_train_with_config']

from ..train.interface import launch_train_with_config
